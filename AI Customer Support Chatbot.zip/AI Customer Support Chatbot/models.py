"""
Pydantic models for request/response validation.
Defines the data schemas used across the application.
"""

from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


# ──────────────────────────────────────────────
# Chat Request Model
# ──────────────────────────────────────────────
class ChatRequest(BaseModel):
    """Schema for incoming chat messages from the user."""
    message: str = Field(
        ...,
        min_length=1,
        max_length=2000,
        description="The user's question or message"
    )
    session_id: Optional[str] = Field(
        default=None,
        description="Optional session identifier for conversation tracking"
    )


# ──────────────────────────────────────────────
# Chat Response Model
# ──────────────────────────────────────────────
class ChatResponse(BaseModel):
    """Schema for chatbot responses sent to the user."""
    response: str = Field(
        ...,
        description="The AI-generated response"
    )
    source: str = Field(
        default="llm",
        description="Source of the answer: 'faq' or 'llm'"
    )
    timestamp: str = Field(
        default_factory=lambda: datetime.now().isoformat(),
        description="ISO format timestamp of the response"
    )
    session_id: Optional[str] = Field(
        default=None,
        description="Session identifier"
    )


# ──────────────────────────────────────────────
# Chat History Record Model
# ──────────────────────────────────────────────
class ChatHistoryRecord(BaseModel):
    """Schema for a single chat history entry."""
    id: int = Field(..., description="Unique record ID")
    session_id: str = Field(..., description="Session identifier")
    user_message: str = Field(..., description="The user's original question")
    bot_response: str = Field(..., description="The AI's response")
    source: str = Field(..., description="Answer source: 'faq' or 'llm'")
    timestamp: str = Field(..., description="When the conversation occurred")


# ──────────────────────────────────────────────
# History Response Model
# ──────────────────────────────────────────────
class HistoryResponse(BaseModel):
    """Schema for the chat history API response."""
    total: int = Field(..., description="Total number of records")
    history: list[ChatHistoryRecord] = Field(
        default_factory=list,
        description="List of chat history records"
    )


# ──────────────────────────────────────────────
# FAQ Item Model
# ──────────────────────────────────────────────
class FAQItem(BaseModel):
    """Schema for a single FAQ entry."""
    question: str = Field(..., description="The FAQ question")
    answer: str = Field(..., description="The FAQ answer")
    keywords: list[str] = Field(
        default_factory=list,
        description="Keywords for matching"
    )
    category: str = Field(
        default="general",
        description="FAQ category"
    )


# ──────────────────────────────────────────────
# Error Response Model
# ──────────────────────────────────────────────
class ErrorResponse(BaseModel):
    """Schema for error responses."""
    error: str = Field(..., description="Error message")
    detail: Optional[str] = Field(
        default=None,
        description="Detailed error information"
    )
