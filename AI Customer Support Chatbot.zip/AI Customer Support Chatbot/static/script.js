/**
 * AI Customer Support Chatbot — Frontend Logic
 * =============================================
 * Handles chat interactions, markdown rendering, theme toggling,
 * chat export, copy-to-clipboard, and UI state management.
 */

// ──────────────────────────────────────────────
// DOM Element References
// ──────────────────────────────────────────────
const chatMessages    = document.getElementById('chat-messages');
const chatForm        = document.getElementById('chat-form');
const userInput       = document.getElementById('user-input');
const sendBtn         = document.getElementById('send-btn');
const typingIndicator = document.getElementById('typing-indicator');
const welcomeContainer= document.getElementById('welcome-container');
const charCount       = document.getElementById('char-count');
const sessionId       = document.getElementById('session-id').value;
const statusIndicator = document.getElementById('status-indicator');
const clearBtn        = document.getElementById('clear-btn');
const exportBtn       = document.getElementById('export-btn');
const themeBtn        = document.getElementById('theme-btn');

// ──────────────────────────────────────────────
// Conversation State
// ──────────────────────────────────────────────
let conversationHistory = [];
let isProcessing = false;

// ──────────────────────────────────────────────
// Configure Marked.js for Markdown Rendering
// ──────────────────────────────────────────────
if (typeof marked !== 'undefined') {
    marked.setOptions({
        breaks: true,
        gfm: true,
        headerIds: false,
        mangle: false,
        highlight: function(code, lang) {
            if (typeof hljs !== 'undefined' && lang && hljs.getLanguage(lang)) {
                try {
                    return hljs.highlight(code, { language: lang }).value;
                } catch (e) {
                    // Fall through to default
                }
            }
            return code;
        }
    });
}

// ──────────────────────────────────────────────
// Initialize Application
// ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initEventListeners();
    userInput.focus();
});

/**
 * Set up all event listeners.
 */
function initEventListeners() {
    // Chat form submission
    chatForm.addEventListener('submit', handleSubmit);

    // Textarea auto-resize and character count
    userInput.addEventListener('input', handleInputChange);

    // Enter key to send (Shift+Enter for new line)
    userInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (!isProcessing && userInput.value.trim()) {
                chatForm.dispatchEvent(new Event('submit'));
            }
        }
    });

    // Quick action chips
    document.querySelectorAll('.chip').forEach(chip => {
        chip.addEventListener('click', () => {
            const question = chip.getAttribute('data-question');
            if (question && !isProcessing) {
                userInput.value = question;
                handleInputChange();
                chatForm.dispatchEvent(new Event('submit'));
            }
        });
    });

    // Clear chat button
    clearBtn.addEventListener('click', clearChat);

    // Export chat button
    exportBtn.addEventListener('click', exportChat);

    // Theme toggle button
    themeBtn.addEventListener('click', toggleTheme);
}

// ──────────────────────────────────────────────
// Handle Form Submission
// ──────────────────────────────────────────────
async function handleSubmit(e) {
    e.preventDefault();

    const message = userInput.value.trim();
    if (!message || isProcessing) return;

    // Set processing state
    isProcessing = true;
    setStatus('busy', 'Thinking...');

    // Hide welcome container on first message
    if (welcomeContainer) {
        welcomeContainer.style.display = 'none';
    }

    // Add user message to the UI
    addMessage(message, 'user');

    // Clear input and reset
    userInput.value = '';
    handleInputChange();
    sendBtn.disabled = true;

    // Show typing indicator
    showTypingIndicator();

    try {
        // Send message to the backend
        const response = await fetch('/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message: message,
                session_id: sessionId
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();

        // Hide typing indicator
        hideTypingIndicator();

        // Add bot response to the UI
        addMessage(data.response, 'bot', data.source);

        // Store in local conversation history
        conversationHistory.push({
            user: message,
            bot: data.response,
            source: data.source,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('Chat error:', error);
        hideTypingIndicator();
        addMessage(
            '⚠️ Sorry, I encountered an error while processing your request. Please check that the server is running and try again.',
            'bot',
            'error'
        );
    } finally {
        isProcessing = false;
        setStatus('online', 'Online');
        userInput.focus();
    }
}

// ──────────────────────────────────────────────
// Add Message to Chat
// ──────────────────────────────────────────────
function addMessage(text, sender, source = '') {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender);

    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Avatar SVG
    const avatarSvg = sender === 'bot'
        ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
               <path d="M12 2a4 4 0 0 1 4 4v1h1a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3v-8a3 3 0 0 1 3-3h1V6a4 4 0 0 1 4-4z"/>
               <circle cx="9" cy="13" r="1.25"/>
               <circle cx="15" cy="13" r="1.25"/>
               <path d="M10 17h4" stroke-linecap="round"/>
           </svg>`
        : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
               <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
               <circle cx="12" cy="7" r="4"/>
           </svg>`;

    // Render markdown for bot messages
    let renderedContent = text;
    if (sender === 'bot') {
        renderedContent = renderMarkdown(text);
    } else {
        renderedContent = escapeHtml(text);
    }

    // Build source badge
    let sourceBadge = '';
    if (sender === 'bot' && source && source !== 'error') {
        const badgeLabel = source === 'faq' ? '📚 FAQ' : '🤖 AI';
        sourceBadge = `<span class="source-badge ${source}">${badgeLabel}</span>`;
    }

    // Build copy button for bot messages
    let copyBtnHtml = '';
    if (sender === 'bot') {
        copyBtnHtml = `
            <button class="copy-btn" onclick="copyMessage(this)" title="Copy response" aria-label="Copy response">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                </svg>
            </button>`;
    }

    messageDiv.innerHTML = `
        <div class="msg-avatar">${avatarSvg}</div>
        <div>
            <div class="bubble">
                ${copyBtnHtml}
                <div class="markdown-body">${renderedContent}</div>
                ${sourceBadge}
            </div>
            <span class="msg-time">${timeStr}</span>
        </div>
    `;

    chatMessages.appendChild(messageDiv);
    scrollToBottom();
}

// ──────────────────────────────────────────────
// Markdown Rendering
// ──────────────────────────────────────────────
function renderMarkdown(text) {
    if (typeof marked === 'undefined') {
        return escapeHtml(text).replace(/\n/g, '<br>');
    }

    try {
        let html = marked.parse(text);

        // Sanitize HTML to prevent XSS
        if (typeof DOMPurify !== 'undefined') {
            html = DOMPurify.sanitize(html, {
                ALLOWED_TAGS: [
                    'p', 'br', 'strong', 'b', 'em', 'i', 'u', 'code', 'pre',
                    'ul', 'ol', 'li', 'a', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
                    'blockquote', 'hr', 'table', 'thead', 'tbody', 'tr', 'th', 'td',
                    'span', 'div', 'img', 'del', 'sup', 'sub'
                ],
                ALLOWED_ATTR: ['href', 'target', 'rel', 'class', 'src', 'alt', 'title']
            });
        }

        return html;
    } catch (e) {
        console.error('Markdown rendering error:', e);
        return escapeHtml(text).replace(/\n/g, '<br>');
    }
}

// ──────────────────────────────────────────────
// Utility Functions
// ──────────────────────────────────────────────

/**
 * Escape HTML special characters to prevent injection.
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Smooth scroll chat area to the bottom.
 */
function scrollToBottom() {
    requestAnimationFrame(() => {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    });
}

/**
 * Show the typing indicator.
 */
function showTypingIndicator() {
    typingIndicator.style.display = 'flex';
    scrollToBottom();
}

/**
 * Hide the typing indicator.
 */
function hideTypingIndicator() {
    typingIndicator.style.display = 'none';
}

/**
 * Set the online status in the header.
 */
function setStatus(status, text) {
    const dot = statusIndicator.querySelector('.status-dot');
    dot.className = 'status-dot ' + status;
    statusIndicator.lastChild.textContent = ' ' + text;
}

/**
 * Handle textarea input: auto-resize and update char count.
 */
function handleInputChange() {
    // Auto-resize textarea
    userInput.style.height = 'auto';
    userInput.style.height = Math.min(userInput.scrollHeight, 120) + 'px';

    // Update character count
    const len = userInput.value.length;
    charCount.textContent = `${len} / 2000`;

    // Enable/disable send button
    sendBtn.disabled = !userInput.value.trim() || isProcessing;
}

// ──────────────────────────────────────────────
// Copy Message to Clipboard
// ──────────────────────────────────────────────
function copyMessage(btn) {
    const bubble = btn.closest('.bubble');
    const markdownBody = bubble.querySelector('.markdown-body');

    // Get plain text content
    const text = markdownBody.innerText || markdownBody.textContent;

    navigator.clipboard.writeText(text).then(() => {
        btn.classList.add('copied');
        btn.innerHTML = `
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="20 6 9 17 4 12"/>
            </svg>`;

        showToast('Response copied to clipboard!', 'success');

        setTimeout(() => {
            btn.classList.remove('copied');
            btn.innerHTML = `
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                </svg>`;
        }, 2000);
    }).catch(() => {
        showToast('Failed to copy', 'error');
    });
}

// ──────────────────────────────────────────────
// Clear Chat
// ──────────────────────────────────────────────
function clearChat() {
    // Remove all messages but keep the welcome container
    const messages = chatMessages.querySelectorAll('.message');
    messages.forEach(msg => msg.remove());

    // Show welcome container again
    if (welcomeContainer) {
        welcomeContainer.style.display = 'flex';
    }

    // Clear local history
    conversationHistory = [];

    showToast('Chat cleared', 'success');
    userInput.focus();
}

// ──────────────────────────────────────────────
// Export Chat
// ──────────────────────────────────────────────
function exportChat() {
    if (conversationHistory.length === 0) {
        showToast('No messages to export', 'error');
        return;
    }

    let exportText = '=== AI Customer Support Chat Export ===\n';
    exportText += `Date: ${new Date().toLocaleString()}\n`;
    exportText += `Session: ${sessionId}\n`;
    exportText += '='.repeat(42) + '\n\n';

    conversationHistory.forEach((entry, idx) => {
        const time = new Date(entry.timestamp).toLocaleTimeString();
        exportText += `[${time}] YOU:\n${entry.user}\n\n`;
        exportText += `[${time}] SUPPORTBOT (${entry.source.toUpperCase()}):\n${entry.bot}\n\n`;
        exportText += '─'.repeat(42) + '\n\n';
    });

    // Create and trigger download
    const blob = new Blob([exportText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chat-export-${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('Chat exported successfully!', 'success');
}

// ──────────────────────────────────────────────
// Theme Toggle (Dark / Light)
// ──────────────────────────────────────────────
function initTheme() {
    const saved = localStorage.getItem('chatbot-theme');
    if (saved === 'light') {
        document.documentElement.setAttribute('data-theme', 'light');
        updateThemeIcons('light');
    } else {
        document.documentElement.setAttribute('data-theme', 'dark');
        updateThemeIcons('dark');
    }
}

function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('chatbot-theme', next);
    updateThemeIcons(next);
    showToast(`${next === 'dark' ? '🌙 Dark' : '☀️ Light'} mode enabled`, 'success');
}

function updateThemeIcons(theme) {
    const sunIcon  = themeBtn.querySelector('.icon-sun');
    const moonIcon = themeBtn.querySelector('.icon-moon');
    if (theme === 'dark') {
        sunIcon.style.display  = 'block';
        moonIcon.style.display = 'none';
    } else {
        sunIcon.style.display  = 'none';
        moonIcon.style.display = 'block';
    }
}

// ──────────────────────────────────────────────
// Toast Notifications
// ──────────────────────────────────────────────
function showToast(message, type = 'success') {
    // Remove any existing toast
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => {
        toast.classList.add('show');
    });

    // Auto-remove after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 350);
    }, 3000);
}
