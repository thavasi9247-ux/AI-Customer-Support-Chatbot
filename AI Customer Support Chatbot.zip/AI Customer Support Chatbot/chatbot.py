"""
Chatbot module for AI Customer Support Chatbot.
Handles FAQ lookup, LLM integration via Ollama, and response generation.
"""

import httpx
import logging
import re
from config import OLLAMA_API_URL, OLLAMA_MODEL, OLLAMA_TIMEOUT, SYSTEM_PROMPT
from utils.helper import find_faq_answer, sanitize_input

# Set up logger for this module
logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# Clean LLM Response
# ──────────────────────────────────────────────
def clean_llm_response(response_text: str) -> str:
    """
    Clean the LLM response by removing thinking/reasoning tags
    that some models (like Qwen3) produce.

    Args:
        response_text: Raw response text from the LLM.

    Returns:
        Cleaned response text.
    """
    # Remove <think>...</think> blocks (Qwen3 reasoning)
    cleaned = re.sub(r'<think>.*?</think>', '', response_text, flags=re.DOTALL)
    # Remove any remaining XML-like tags
    cleaned = re.sub(r'<\/?(?:think|reasoning|internal)>', '', cleaned, flags=re.IGNORECASE)
    # Strip leading/trailing whitespace
    cleaned = cleaned.strip()
    return cleaned


# ──────────────────────────────────────────────
# Generate Response (Main Entry Point)
# ──────────────────────────────────────────────
async def generate_response(question: str) -> dict:
    """
    Generate a response for the user's question.
    First checks the FAQ knowledge base, then falls back to Ollama LLM.

    Args:
        question: The user's question (raw input).

    Returns:
        A dictionary with 'response' (str) and 'source' ('faq' or 'llm').
    """
    # Sanitize the input
    clean_question = sanitize_input(question)

    if not clean_question:
        return {
            "response": "I didn't receive a valid question. Could you please rephrase that?",
            "source": "system"
        }

    logger.info(f"Processing question: '{clean_question[:80]}...'")

    # ── Step 1: Check FAQ Knowledge Base ──
    faq_result = find_faq_answer(clean_question)
    if faq_result:
        logger.info(f"FAQ match found with score {faq_result['score']:.2f}")
        return {
            "response": faq_result["answer"],
            "source": "faq"
        }

    # ── Step 2: Query Ollama LLM ──
    logger.info("No FAQ match found. Querying Ollama LLM...")
    llm_response = await query_ollama(clean_question)
    return llm_response


# ──────────────────────────────────────────────
# Query Ollama LLM
# ──────────────────────────────────────────────
async def query_ollama(question: str) -> dict:
    """
    Send a question to the Ollama API and get a response.

    Args:
        question: The user's question.

    Returns:
        A dictionary with 'response' (str) and 'source' ('llm').
    """
    # Construct the full prompt with system context
    full_prompt = f"""{SYSTEM_PROMPT}

Customer Question: {question}

Provide a helpful, professional, and concise response. Do NOT include any <think> tags or internal reasoning in your answer."""

    # Prepare the request payload
    payload = {
        "model": OLLAMA_MODEL,
        "prompt": full_prompt,
        "stream": False
    }

    try:
        async with httpx.AsyncClient(timeout=OLLAMA_TIMEOUT) as client:
            logger.info(f"Sending request to Ollama: {OLLAMA_API_URL}")
            response = await client.post(OLLAMA_API_URL, json=payload)
            response.raise_for_status()

            # Parse the JSON response
            data = response.json()
            raw_response = data.get("response", "").strip()

            if not raw_response:
                logger.warning("Empty response received from Ollama.")
                return {
                    "response": "I couldn't find the answer. Please contact our support team at support@company.com or call 1-800-SUPPORT.",
                    "source": "llm"
                }

            # Clean the response (remove thinking tags, etc.)
            cleaned_response = clean_llm_response(raw_response)

            if not cleaned_response:
                logger.warning("Response was empty after cleaning.")
                return {
                    "response": "I couldn't find the answer. Please contact our support team at support@company.com or call 1-800-SUPPORT.",
                    "source": "llm"
                }

            logger.info(f"LLM response received successfully ({len(cleaned_response)} chars).")
            return {
                "response": cleaned_response,
                "source": "llm"
            }

    except httpx.ConnectError:
        logger.error("Cannot connect to Ollama. Is it running on localhost:11434?")
        return {
            "response": "⚠️ I'm having trouble connecting to my AI service right now. Please make sure Ollama is running and try again. If the issue persists, please contact our support team at support@company.com.",
            "source": "error"
        }

    except httpx.TimeoutException:
        logger.error(f"Ollama request timed out after {OLLAMA_TIMEOUT} seconds.")
        return {
            "response": "⚠️ The request took too long to process. Please try asking a simpler question or contact our support team at support@company.com.",
            "source": "error"
        }

    except httpx.HTTPStatusError as e:
        logger.error(f"Ollama HTTP error: {e.response.status_code} - {e.response.text}")
        return {
            "response": "⚠️ I encountered an error while processing your request. Please try again later or contact our support team.",
            "source": "error"
        }

    except Exception as e:
        logger.error(f"Unexpected error querying Ollama: {e}")
        return {
            "response": "I couldn't find the answer. Please contact our support team at support@company.com or call 1-800-SUPPORT.",
            "source": "error"
        }
