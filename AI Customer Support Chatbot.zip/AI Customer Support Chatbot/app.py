"""
AI Customer Support Chatbot — Main Application
================================================
A production-quality FastAPI application that serves an intelligent
customer support chatbot powered by a local Ollama LLM.

Run with:
    uvicorn app:app --reload
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, HTTPException, Query
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from config import (
    APP_TITLE, APP_VERSION, APP_DESCRIPTION,
    TEMPLATES_DIR, STATIC_DIR,
    LOG_LEVEL, LOG_FORMAT, LOG_DATE_FORMAT
)
from models import ChatRequest, ChatResponse, HistoryResponse, ErrorResponse
from chatbot import generate_response
from database import init_database, save_chat, get_chat_history, get_chat_count, clear_chat_history
from utils.helper import load_faqs, generate_session_id

# ──────────────────────────────────────────────
# Configure Logging
# ──────────────────────────────────────────────
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format=LOG_FORMAT,
    datefmt=LOG_DATE_FORMAT
)
logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# Application Lifespan (Startup / Shutdown)
# ──────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application startup and shutdown events."""
    # ── Startup ──
    logger.info(f"🚀 Starting {APP_TITLE} v{APP_VERSION}")

    # Initialize the SQLite database
    await init_database()
    logger.info("✅ Database initialized.")

    # Load FAQs into memory
    faqs = load_faqs()
    logger.info(f"✅ Loaded {len(faqs)} FAQs into memory.")

    logger.info("✅ Application is ready to serve requests!")

    yield  # Application runs here

    # ── Shutdown ──
    logger.info("🛑 Shutting down application...")


# ──────────────────────────────────────────────
# Create FastAPI App
# ──────────────────────────────────────────────
app = FastAPI(
    title=APP_TITLE,
    version=APP_VERSION,
    description=APP_DESCRIPTION,
    lifespan=lifespan
)

# Mount static files directory
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# Initialize Jinja2 templates
templates = Jinja2Templates(directory=TEMPLATES_DIR)


# ──────────────────────────────────────────────
# Route: Home Page
# ──────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse, tags=["Frontend"])
async def home(request: Request):
    """
    Serve the main chatbot UI page.
    Generates a fresh session ID for each page load.
    """
    session_id = generate_session_id()
    logger.info(f"Serving home page. Session: {session_id}")

    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "title": APP_TITLE,
            "version": APP_VERSION,
            "session_id": session_id
        }
    )


# ──────────────────────────────────────────────
# Route: Chat API
# ──────────────────────────────────────────────
@app.post("/chat", response_model=ChatResponse, tags=["Chat"])
async def chat(chat_request: ChatRequest):
    """
    Process a user's chat message and return the AI response.

    Flow:
    1. Check FAQ knowledge base for matching answer.
    2. If no FAQ match, query Ollama LLM.
    3. Save the conversation to the database.
    4. Return the response to the client.
    """
    try:
        user_message = chat_request.message.strip()
        session_id = chat_request.session_id or generate_session_id()

        if not user_message:
            raise HTTPException(status_code=400, detail="Message cannot be empty.")

        logger.info(f"[Session: {session_id}] User: '{user_message[:80]}...'")

        # Generate the response (FAQ or LLM)
        result = await generate_response(user_message)

        bot_response = result["response"]
        source = result["source"]

        # Save to database
        await save_chat(
            session_id=session_id,
            user_message=user_message,
            bot_response=bot_response,
            source=source
        )

        logger.info(f"[Session: {session_id}] Bot ({source}): '{bot_response[:80]}...'")

        return ChatResponse(
            response=bot_response,
            source=source,
            session_id=session_id
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing chat: {e}")
        raise HTTPException(
            status_code=500,
            detail="An error occurred while processing your request. Please try again."
        )


# ──────────────────────────────────────────────
# Route: Chat History API
# ──────────────────────────────────────────────
@app.get("/history", response_model=HistoryResponse, tags=["History"])
@app.get("/api/history", response_model=HistoryResponse, tags=["History"])
async def history(
    session_id: str = Query(default=None, description="Filter by session ID"),
    limit: int = Query(default=100, ge=1, le=500, description="Max records to return"),
    offset: int = Query(default=0, ge=0, description="Records to skip")
):
    """
    Retrieve chat history from the database.
    Optionally filter by session ID with pagination support.
    """
    try:
        records = await get_chat_history(
            session_id=session_id,
            limit=limit,
            offset=offset
        )
        total = await get_chat_count(session_id=session_id)

        logger.info(f"History request: {len(records)} records returned (total: {total})")

        return HistoryResponse(
            total=total,
            history=records
        )

    except Exception as e:
        logger.error(f"Error retrieving history: {e}")
        raise HTTPException(
            status_code=500,
            detail="Failed to retrieve chat history."
        )


# ──────────────────────────────────────────────
# Route: Clear Chat History
# ──────────────────────────────────────────────
@app.delete("/history", tags=["History"])
async def delete_history(
    session_id: str = Query(default=None, description="Session ID to clear (omit to clear all)")
):
    """Clear chat history. Optionally filter by session ID."""
    try:
        deleted = await clear_chat_history(session_id=session_id)
        logger.info(f"Cleared {deleted} chat records.")
        return {"message": f"Successfully cleared {deleted} chat records.", "deleted": deleted}

    except Exception as e:
        logger.error(f"Error clearing history: {e}")
        raise HTTPException(status_code=500, detail="Failed to clear chat history.")


# ──────────────────────────────────────────────
# Route: Health Check
# ──────────────────────────────────────────────
@app.get("/health", tags=["System"])
async def health_check():
    """Health check endpoint for monitoring."""
    return {
        "status": "healthy",
        "app": APP_TITLE,
        "version": APP_VERSION
    }


# ──────────────────────────────────────────────
# Global Exception Handler
# ──────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handle any unhandled exceptions globally."""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content=ErrorResponse(
            error="Internal Server Error",
            detail="An unexpected error occurred. Please try again later."
        ).model_dump()
    )


# ──────────────────────────────────────────────
# Run with Uvicorn (direct execution)
# ──────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
