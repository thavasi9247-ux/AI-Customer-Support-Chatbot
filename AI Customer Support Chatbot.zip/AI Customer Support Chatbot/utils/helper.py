"""
Utility helper functions for the AI Customer Support Chatbot.
Provides FAQ loading, text matching, session management, and sanitization.
"""

import json
import logging
import uuid
import re
from difflib import SequenceMatcher
from config import FAQ_DATA_PATH, FAQ_SIMILARITY_THRESHOLD

# Set up logger for this module
logger = logging.getLogger(__name__)

# In-memory FAQ cache
_faq_cache: list[dict] = []


# ──────────────────────────────────────────────
# Load FAQs from JSON
# ──────────────────────────────────────────────
def load_faqs() -> list[dict]:
    """
    Load FAQ data from faq.json into memory.
    Caches the result for subsequent calls.

    Returns:
        A list of FAQ dictionaries with question, answer, keywords, and category.
    """
    global _faq_cache

    try:
        with open(FAQ_DATA_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
            _faq_cache = data.get("faqs", [])
            logger.info(f"Loaded {len(_faq_cache)} FAQs from {FAQ_DATA_PATH}")
            return _faq_cache

    except FileNotFoundError:
        logger.warning(f"FAQ file not found at {FAQ_DATA_PATH}. Starting with empty FAQ list.")
        _faq_cache = []
        return _faq_cache

    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in FAQ file: {e}")
        _faq_cache = []
        return _faq_cache

    except Exception as e:
        logger.error(f"Unexpected error loading FAQs: {e}")
        _faq_cache = []
        return _faq_cache


# ──────────────────────────────────────────────
# Get Cached FAQs
# ──────────────────────────────────────────────
def get_faqs() -> list[dict]:
    """
    Return the cached FAQ list. Loads from file if cache is empty.

    Returns:
        The list of FAQ dictionaries.
    """
    if not _faq_cache:
        return load_faqs()
    return _faq_cache


# ──────────────────────────────────────────────
# Normalize Text
# ──────────────────────────────────────────────
def normalize_text(text: str) -> str:
    """
    Normalize text for comparison by lowercasing, stripping whitespace,
    and removing punctuation.

    Args:
        text: The input text to normalize.

    Returns:
        Normalized text string.
    """
    text = text.lower().strip()
    # Remove punctuation except spaces
    text = re.sub(r'[^\w\s]', '', text)
    # Collapse multiple spaces
    text = re.sub(r'\s+', ' ', text)
    return text


# ──────────────────────────────────────────────
# Calculate Text Similarity
# ──────────────────────────────────────────────
def calculate_similarity(text1: str, text2: str) -> float:
    """
    Calculate the similarity ratio between two strings using SequenceMatcher.

    Args:
        text1: First text string.
        text2: Second text string.

    Returns:
        A float between 0 and 1 indicating similarity.
    """
    normalized1 = normalize_text(text1)
    normalized2 = normalize_text(text2)
    return SequenceMatcher(None, normalized1, normalized2).ratio()


# ──────────────────────────────────────────────
# Check Keyword Match
# ──────────────────────────────────────────────
def keyword_match(user_input: str, keywords: list[str]) -> float:
    """
    Check how many keywords from the FAQ match the user's input.

    Args:
        user_input: The user's question (normalized).
        keywords: List of keywords to check against.

    Returns:
        A match score between 0 and 1.
    """
    if not keywords:
        return 0.0

    normalized_input = normalize_text(user_input)
    input_words = set(normalized_input.split())
    matched = sum(1 for kw in keywords if kw.lower() in input_words or kw.lower() in normalized_input)
    return matched / len(keywords)


# ──────────────────────────────────────────────
# Find Best FAQ Match
# ──────────────────────────────────────────────
def find_faq_answer(user_question: str) -> dict | None:
    """
    Search FAQs for the best matching answer to the user's question.
    Uses a combination of text similarity and keyword matching.

    Args:
        user_question: The user's question.

    Returns:
        A dictionary with 'question' and 'answer' if a match is found, else None.
    """
    faqs = get_faqs()
    if not faqs:
        logger.info("No FAQs available for matching.")
        return None

    best_match = None
    best_score = 0.0

    for faq in faqs:
        faq_question = faq.get("question", "")
        faq_keywords = faq.get("keywords", [])

        # Calculate similarity between user question and FAQ question
        similarity_score = calculate_similarity(user_question, faq_question)

        # Calculate keyword match score
        kw_score = keyword_match(user_question, faq_keywords)

        # Combined weighted score (60% similarity + 40% keyword)
        combined_score = (similarity_score * 0.6) + (kw_score * 0.4)

        if combined_score > best_score:
            best_score = combined_score
            best_match = faq

    # Check if the best match exceeds the threshold
    if best_match and best_score >= FAQ_SIMILARITY_THRESHOLD:
        logger.info(
            f"FAQ match found: Score={best_score:.2f}, "
            f"Q='{best_match['question'][:50]}...'"
        )
        return {
            "question": best_match["question"],
            "answer": best_match["answer"],
            "score": best_score
        }

    logger.info(f"No FAQ match found for: '{user_question[:50]}...' (Best score: {best_score:.2f})")
    return None


# ──────────────────────────────────────────────
# Generate Session ID
# ──────────────────────────────────────────────
def generate_session_id() -> str:
    """
    Generate a unique session ID using UUID4.

    Returns:
        A unique session identifier string.
    """
    return str(uuid.uuid4())


# ──────────────────────────────────────────────
# Sanitize User Input
# ──────────────────────────────────────────────
def sanitize_input(text: str) -> str:
    """
    Sanitize user input to prevent injection attacks.
    Strips dangerous HTML/script tags while preserving the message content.

    Args:
        text: The raw user input.

    Returns:
        Sanitized text string.
    """
    # Remove script tags and their content
    text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL | re.IGNORECASE)
    # Remove other dangerous HTML tags but keep content
    text = re.sub(r'<(?!\/?(b|i|u|strong|em|code|pre)\b)[^>]+>', '', text, flags=re.IGNORECASE)
    # Strip leading/trailing whitespace
    text = text.strip()
    return text


# ──────────────────────────────────────────────
# Format Timestamp
# ──────────────────────────────────────────────
def format_timestamp(iso_timestamp: str) -> str:
    """
    Convert ISO timestamp to a human-readable format.

    Args:
        iso_timestamp: ISO 8601 formatted timestamp string.

    Returns:
        Human-readable timestamp string.
    """
    try:
        from datetime import datetime
        dt = datetime.fromisoformat(iso_timestamp)
        return dt.strftime("%b %d, %Y at %I:%M %p")
    except (ValueError, TypeError):
        return iso_timestamp


# ──────────────────────────────────────────────
# Truncate Text
# ──────────────────────────────────────────────
def truncate_text(text: str, max_length: int = 500) -> str:
    """
    Truncate text to a specified maximum length, adding ellipsis if needed.

    Args:
        text: The text to truncate.
        max_length: Maximum number of characters.

    Returns:
        Truncated text with ellipsis if it exceeds max_length.
    """
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."
