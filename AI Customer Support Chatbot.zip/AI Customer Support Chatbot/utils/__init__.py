"""
Utils package for the AI Customer Support Chatbot.
Provides helper functions for FAQ matching, session management, and text processing.
"""

from utils.helper import (
    load_faqs,
    get_faqs,
    find_faq_answer,
    generate_session_id,
    sanitize_input,
    format_timestamp,
    truncate_text
)

__all__ = [
    "load_faqs",
    "get_faqs",
    "find_faq_answer",
    "generate_session_id",
    "sanitize_input",
    "format_timestamp",
    "truncate_text"
]
