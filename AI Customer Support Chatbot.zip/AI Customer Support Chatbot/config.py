"""
Configuration module for AI Customer Support Chatbot.
Contains all application settings, constants, and environment configurations.
"""

import os

# ──────────────────────────────────────────────
# Application Settings
# ──────────────────────────────────────────────
APP_TITLE = "AI Customer Support Chatbot"
APP_VERSION = "1.0.0"
APP_DESCRIPTION = "An intelligent customer support assistant powered by local LLM via Ollama."
APP_HOST = "0.0.0.0"
APP_PORT = 8000
DEBUG_MODE = True

# ──────────────────────────────────────────────
# Ollama LLM Settings
# ──────────────────────────────────────────────
OLLAMA_API_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "qwen3:8b"
OLLAMA_TIMEOUT = 120  # seconds

# ──────────────────────────────────────────────
# Database Settings
# ──────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_DIR = os.path.join(BASE_DIR, "database")
DATABASE_PATH = os.path.join(DATABASE_DIR, "chatbot.db")

# ──────────────────────────────────────────────
# FAQ Data Path
# ──────────────────────────────────────────────
FAQ_DATA_PATH = os.path.join(BASE_DIR, "data", "faq.json")

# ──────────────────────────────────────────────
# Templates & Static Files
# ──────────────────────────────────────────────
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
STATIC_DIR = os.path.join(BASE_DIR, "static")

# ──────────────────────────────────────────────
# Logging Settings
# ──────────────────────────────────────────────
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
LOG_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# ──────────────────────────────────────────────
# System Prompt for Customer Support
# ──────────────────────────────────────────────
SYSTEM_PROMPT = """You are a professional, friendly, and polite AI Customer Support Executive.

Your name is "SupportBot" and you work for our company.

STRICT RULES YOU MUST FOLLOW:
1. Always be polite, professional, and empathetic.
2. Only answer questions related to customer support topics such as:
   - Orders, shipping, and delivery
   - Refunds and returns
   - Account and password issues
   - Subscription management
   - Payment methods
   - Support timings and contact information
   - Product information and troubleshooting
3. NEVER generate harmful, offensive, or inappropriate content.
4. NEVER make up information you don't know. If you are unsure, say:
   "I couldn't find the answer. Please contact our support team at support@company.com or call 1-800-SUPPORT."
5. Stay strictly within the customer support domain.
6. Keep responses concise, clear, and helpful.
7. Use a warm and professional tone.
8. If a customer is frustrated, acknowledge their feelings and offer solutions.
9. Format your responses with proper structure when needed (bullet points, numbered steps).
10. Do NOT discuss politics, religion, or any controversial topics.
11. Do NOT write or execute code unless it's directly related to helping the customer with a technical issue.

COMPANY POLICIES:
- Refund Policy: Full refund within 30 days of purchase with original receipt.
- Shipping: Standard (5-7 business days), Express (2-3 business days), Overnight available.
- Support Hours: Monday-Friday 9AM-6PM EST, Saturday 10AM-4PM EST, Closed on Sundays.
- Payment Methods: Visa, MasterCard, American Express, PayPal, Apple Pay, Google Pay.
- Subscription cancellation: Can be done anytime from account settings, effective at end of billing cycle.
- Password reset: Available via email verification on the login page.

Always end your response with a helpful follow-up question or offer of further assistance.
Do NOT use /think or reasoning tags in your response. Provide a direct, clean answer."""

# ──────────────────────────────────────────────
# Similarity Threshold for FAQ matching
# ──────────────────────────────────────────────
FAQ_SIMILARITY_THRESHOLD = 0.55
