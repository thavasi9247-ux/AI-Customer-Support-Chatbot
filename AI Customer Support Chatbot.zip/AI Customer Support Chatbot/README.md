# AI Customer Support Chatbot 🤖

A production-quality, intelligent customer support chatbot powered by a **local LLM via Ollama**. Built with **FastAPI**, **SQLite**, and a beautiful **dark-mode UI** with markdown support, typing animations, and chat export.

---

## 📸 Features

| Feature | Description |
|---------|-------------|
| 🧠 **AI-Powered Responses** | Uses Ollama (local LLM) for natural, contextual answers |
| 📚 **FAQ Knowledge Base** | Instant answers from a curated FAQ database |
| 💬 **Beautiful Chat UI** | Dark mode, glassmorphism, smooth animations |
| 📝 **Markdown Support** | Rich formatting with syntax-highlighted code blocks |
| 📋 **Copy Response** | One-click copy of any bot response |
| 📤 **Chat Export** | Download full conversation as a text file |
| 🗄️ **Chat History** | All conversations saved to SQLite |
| 🌓 **Dark/Light Mode** | Toggle between themes with persistent preference |
| ⚡ **Typing Indicator** | Animated dots while the bot is thinking |
| 🎯 **Quick Actions** | Predefined question chips for common queries |
| 🔒 **Input Sanitization** | Protection against XSS and injection attacks |
| 📱 **Responsive Design** | Works perfectly on desktop and mobile |

---

## 📁 Project Structure

```
AI Customer Support Chatbot/
│
├── app.py                  # FastAPI main application
├── config.py               # Configuration & settings
├── chatbot.py              # LLM integration & response logic
├── database.py             # SQLite database operations
├── models.py               # Pydantic request/response models
├── requirements.txt        # Python dependencies
├── README.md               # This file
│
├── data/
│   └── faq.json            # FAQ knowledge base
│
├── templates/
│   └── index.html          # Jinja2 HTML template
│
├── static/
│   ├── style.css           # Stylesheet
│   └── script.js           # Frontend JavaScript
│
├── database/
│   └── chatbot.db          # SQLite database (auto-created)
│
└── utils/
    ├── __init__.py
    └── helper.py           # Utility functions
```

---

## 🚀 Installation & Setup

### Prerequisites

- **Python 3.11+**
- **Ollama** installed and running locally

### Step 1: Install Ollama

Download and install Ollama from [ollama.com](https://ollama.com).

```bash
# Pull a model (the app uses qwen3:8b by default)
ollama pull qwen3:8b
```

> **Note:** You can change the model in `config.py` by updating `OLLAMA_MODEL`.

### Step 2: Install Python Dependencies

```bash
cd "AI Customer Support Chatbot"
pip install -r requirements.txt
```

### Step 3: Start Ollama

Make sure Ollama is running:

```bash
ollama serve
```

### Step 4: Run the Application

```bash
uvicorn app:app --reload
```

### Step 5: Open in Browser

Navigate to: **http://127.0.0.1:8000**

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/` | Chatbot UI page |
| `POST` | `/chat` | Send a message and get AI response |
| `GET` | `/history` | Retrieve chat history |
| `GET` | `/api/history` | Admin endpoint for chat history |
| `DELETE` | `/history` | Clear chat history |
| `GET` | `/health` | Health check |

### POST /chat — Example

```bash
curl -X POST http://127.0.0.1:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "What is your refund policy?", "session_id": "test-123"}'
```

**Response:**
```json
{
  "response": "We offer a **full refund within 30 days** of purchase...",
  "source": "faq",
  "timestamp": "2025-01-01T12:00:00",
  "session_id": "test-123"
}
```

---

## 🛠️ Configuration

All settings are in `config.py`:

| Setting | Default | Description |
|---------|---------|-------------|
| `OLLAMA_API_URL` | `http://localhost:11434/api/generate` | Ollama API endpoint |
| `OLLAMA_MODEL` | `qwen3:8b` | LLM model name |
| `OLLAMA_TIMEOUT` | `120` | Request timeout in seconds |
| `FAQ_SIMILARITY_THRESHOLD` | `0.55` | Min score for FAQ matching |

---

## 🔧 Troubleshooting

| Issue | Solution |
|-------|----------|
| **"Cannot connect to Ollama"** | Make sure Ollama is running: `ollama serve` |
| **Slow responses** | Use a smaller model (e.g., `llama3.2:3b`) |
| **Model not found** | Pull the model first: `ollama pull qwen3:8b` |
| **Port 8000 in use** | Use a different port: `uvicorn app:app --reload --port 8080` |
| **Database errors** | Delete `database/chatbot.db` and restart the app |
| **"ModuleNotFoundError"** | Run `pip install -r requirements.txt` |

---

## 📜 License

This project is for educational and personal use.

---

**Built with ❤️ using FastAPI, Ollama, and modern web technologies.**
