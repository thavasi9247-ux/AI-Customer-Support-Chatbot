"""
Database module for managing SQLite operations.
Handles table creation, chat history storage, and retrieval.
"""

import aiosqlite
import logging
import os
from datetime import datetime
from config import DATABASE_PATH, DATABASE_DIR

# Set up logger for this module
logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# Initialize Database
# ──────────────────────────────────────────────
async def init_database() -> None:
    """
    Initialize the SQLite database.
    Creates the database directory and chat_history table if they don't exist.
    """
    try:
        # Ensure database directory exists
        os.makedirs(DATABASE_DIR, exist_ok=True)
        logger.info(f"Database directory ensured at: {DATABASE_DIR}")

        async with aiosqlite.connect(DATABASE_PATH) as db:
            # Create the chat_history table
            await db.execute("""
                CREATE TABLE IF NOT EXISTS chat_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    user_message TEXT NOT NULL,
                    bot_response TEXT NOT NULL,
                    source TEXT DEFAULT 'llm',
                    timestamp TEXT NOT NULL
                )
            """)

            # Create index on session_id for faster lookups
            await db.execute("""
                CREATE INDEX IF NOT EXISTS idx_session_id
                ON chat_history(session_id)
            """)

            # Create index on timestamp for ordered queries
            await db.execute("""
                CREATE INDEX IF NOT EXISTS idx_timestamp
                ON chat_history(timestamp)
            """)

            await db.commit()
            logger.info("Database initialized successfully.")

    except Exception as e:
        logger.error(f"Failed to initialize database: {e}")
        raise


# ──────────────────────────────────────────────
# Save Chat Message
# ──────────────────────────────────────────────
async def save_chat(
    session_id: str,
    user_message: str,
    bot_response: str,
    source: str = "llm"
) -> int:
    """
    Save a chat exchange (user question + bot response) to the database.

    Args:
        session_id: The session identifier.
        user_message: The user's original question.
        bot_response: The AI's response.
        source: Source of the answer ('faq' or 'llm').

    Returns:
        The ID of the inserted record.
    """
    try:
        timestamp = datetime.now().isoformat()

        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute(
                """
                INSERT INTO chat_history (session_id, user_message, bot_response, source, timestamp)
                VALUES (?, ?, ?, ?, ?)
                """,
                (session_id, user_message, bot_response, source, timestamp)
            )
            await db.commit()
            record_id = cursor.lastrowid
            logger.info(f"Chat saved: ID={record_id}, Session={session_id}, Source={source}")
            return record_id

    except Exception as e:
        logger.error(f"Failed to save chat: {e}")
        raise


# ──────────────────────────────────────────────
# Get Chat History
# ──────────────────────────────────────────────
async def get_chat_history(
    session_id: str = None,
    limit: int = 100,
    offset: int = 0
) -> list[dict]:
    """
    Retrieve chat history from the database.

    Args:
        session_id: Optional session filter. If None, returns all history.
        limit: Maximum number of records to return.
        offset: Number of records to skip (for pagination).

    Returns:
        A list of dictionaries containing chat history records.
    """
    try:
        async with aiosqlite.connect(DATABASE_PATH) as db:
            db.row_factory = aiosqlite.Row

            if session_id:
                cursor = await db.execute(
                    """
                    SELECT id, session_id, user_message, bot_response, source, timestamp
                    FROM chat_history
                    WHERE session_id = ?
                    ORDER BY timestamp DESC
                    LIMIT ? OFFSET ?
                    """,
                    (session_id, limit, offset)
                )
            else:
                cursor = await db.execute(
                    """
                    SELECT id, session_id, user_message, bot_response, source, timestamp
                    FROM chat_history
                    ORDER BY timestamp DESC
                    LIMIT ? OFFSET ?
                    """,
                    (limit, offset)
                )

            rows = await cursor.fetchall()
            history = [
                {
                    "id": row["id"],
                    "session_id": row["session_id"],
                    "user_message": row["user_message"],
                    "bot_response": row["bot_response"],
                    "source": row["source"],
                    "timestamp": row["timestamp"]
                }
                for row in rows
            ]
            logger.info(f"Retrieved {len(history)} chat records.")
            return history

    except Exception as e:
        logger.error(f"Failed to retrieve chat history: {e}")
        raise


# ──────────────────────────────────────────────
# Get Total Chat Count
# ──────────────────────────────────────────────
async def get_chat_count(session_id: str = None) -> int:
    """
    Get the total number of chat records.

    Args:
        session_id: Optional session filter.

    Returns:
        Total count of chat records.
    """
    try:
        async with aiosqlite.connect(DATABASE_PATH) as db:
            if session_id:
                cursor = await db.execute(
                    "SELECT COUNT(*) FROM chat_history WHERE session_id = ?",
                    (session_id,)
                )
            else:
                cursor = await db.execute("SELECT COUNT(*) FROM chat_history")

            row = await cursor.fetchone()
            return row[0] if row else 0

    except Exception as e:
        logger.error(f"Failed to get chat count: {e}")
        raise


# ──────────────────────────────────────────────
# Clear Chat History
# ──────────────────────────────────────────────
async def clear_chat_history(session_id: str = None) -> int:
    """
    Clear chat history from the database.

    Args:
        session_id: Optional session filter. If None, clears ALL history.

    Returns:
        Number of records deleted.
    """
    try:
        async with aiosqlite.connect(DATABASE_PATH) as db:
            if session_id:
                cursor = await db.execute(
                    "DELETE FROM chat_history WHERE session_id = ?",
                    (session_id,)
                )
            else:
                cursor = await db.execute("DELETE FROM chat_history")

            await db.commit()
            deleted = cursor.rowcount
            logger.info(f"Cleared {deleted} chat records.")
            return deleted

    except Exception as e:
        logger.error(f"Failed to clear chat history: {e}")
        raise
